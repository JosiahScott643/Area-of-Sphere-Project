import java.util.Scanner;

class AreaofASphere{
	public static void main(String[] args){	
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the radius: ");
		keyboard.nextDouble();
	// 1) prompt user for radius input
		int radius = 0;
		radius = keyboard.nextInt();
	// 2) inser radius into Area Formula
		double area = 0.0;
		area = 4* Math.PI* radius* radius;		
	// 3) output to user to two decimal places
		System.out.print(" The Area of a Sphere given a radius of " + radius + "is ");
		System.out.print(area);
		System.out.printf("%.2f", area);
	}
}